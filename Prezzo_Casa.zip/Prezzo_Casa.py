import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

# 1. Dati di esempio (metri quadri, prezzo in migliaia di euro)
X = np.array([[30], [50], [70], [90], [110], [130], [150]])  # metri quadri
y = np.array([60, 100, 140, 180, 220, 260, 300])           # prezzo in migliaia

# 2. Creazione e addestramento modello
model = LinearRegression()
model.fit(X, y)

# 3. Fare previsioni
metri_quadri_nuovi = np.array([[75], [85], [120]])
previsioni = model.predict(metri_quadri_nuovi)

for mq, prezzo in zip(metri_quadri_nuovi.flatten(), previsioni):
    print(f"Predizione prezzo per {mq} m²: {int(round(prezzo))} mila€")

# 4. Visualizzazione 
plt.scatter(X, y, color='blue', label='Prezzi reali')
plt.plot(X, model.predict(X), color='red', label='Modello')
plt.scatter(metri_quadri_nuovi, previsioni, color='green', marker='x', s=100, label='Previsioni')
plt.xlabel('Metri quadri (m²)')
plt.ylabel('Prezzo (€)')
plt.legend()
plt.show()
